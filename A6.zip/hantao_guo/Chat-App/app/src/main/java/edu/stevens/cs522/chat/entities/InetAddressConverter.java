package edu.stevens.cs522.chat.entities;

import androidx.room.TypeConverter;

import java.net.InetAddress;
import java.util.Date;

import edu.stevens.cs522.base.InetAddressUtils;

public class InetAddressConverter {
    @TypeConverter
    public static InetAddress fromString(String string) {
        InetAddress inetAddress = null;
        try {
            inetAddress = InetAddress.getByName(string);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return inetAddress;
    }

    @TypeConverter
    public static String dateToString(InetAddress inetAddress) {
        return inetAddress == null ? null : inetAddress.getHostName();
    }
}

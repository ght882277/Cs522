package edu.stevens.cs522.chat.databases;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import java.util.List;

import edu.stevens.cs522.chat.entities.Message;

@Dao
public interface MessageDAO {

    @Query("SELECT * FROM Message")
    public List<Message> fetchAllMessages();

    @Query("SELECT * FROM Message WHERE senderId = :peerId")
    public List<Message> fetchMessagesFromPeer(long peerId);

    @Transaction
    @Insert
    public void persist(Message message);

}

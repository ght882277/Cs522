/*********************************************************************

 Chat server: accept chat messages from clients.

 Sender name and GPS coordinates are encoded
 in the messages, and stripped off upon receipt.

 Copyright (c) 2017 Stevens Institute of Technology
 **********************************************************************/
package edu.stevens.cs522.chat.activities;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.net.InetAddress;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import edu.stevens.cs522.base.DateUtils;
import edu.stevens.cs522.base.InetAddressUtils;
import edu.stevens.cs522.chat.R;
import edu.stevens.cs522.chat.databases.ChatDatabase;
import edu.stevens.cs522.chat.databases.MessageDAO;
import edu.stevens.cs522.chat.databases.PeerDAO;
import edu.stevens.cs522.chat.entities.DateConverter;
import edu.stevens.cs522.chat.entities.Message;
import edu.stevens.cs522.chat.services.ChatService;
import edu.stevens.cs522.chat.services.IChatService;
import edu.stevens.cs522.chat.services.ResultReceiverWrapper;
import edu.stevens.cs522.chat.settings.Settings;
import edu.stevens.cs522.chat.ui.MessageAdapter;

public class ChatActivity extends FragmentActivity implements OnClickListener, ServiceConnection, ResultReceiverWrapper.IReceive {

    final static public String TAG = ChatActivity.class.getCanonicalName();

    /*
     * UI for displayed received messages
     */
    private ChatDatabase chatDatabase;

    private MessageDAO messageDao;

    private PeerDAO peerDao;

    private MutableLiveData<List<Message>> messages;

    private RecyclerView messageList;

    private MessageAdapter messagesAdapter;

    /*
     * Widgets for dest address, message text, send button.
     */
    private EditText destinationHost;

    private EditText destinationPort;

    private TextView senderName;

    private EditText messageText;

    private Button sendButton;


    /*
     * Reference to the service, for sending a message
     */
    private IChatService chatService;

    /*
     * For receiving ack when message is sent.
     */
    private ResultReceiverWrapper sendResultReceiver;

    /*
     * Called when the activity is first created.
     */

    static public ChatActivity chatActivity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.messages);
        //adb devices
        //adb –s emulator-5554 forward tcp:6666 tcp:6666
        //adb –s emulator-5556 forward tcp:6667 tcp:6666
        chatActivity = this;
        messageList = findViewById(R.id.message_list);
        messageList.setLayoutManager(new LinearLayoutManager(this));

        destinationHost = findViewById(R.id.destination_host);
        destinationPort = findViewById(R.id.destination_port);
        senderName = findViewById(R.id.sender_name);
        messageText = findViewById(R.id.message_text);

        // TODO open the database
        // Note use getApplicationContext, do not make DB depend on UI!
        chatDatabase = ChatDatabase.getInstance(getApplicationContext());

        // TODO Initialize the recyclerview and adapter for messages
        messagesAdapter = new MessageAdapter();
        messageList.setAdapter(messagesAdapter);
        if (messages == null) {
            messages = new MutableLiveData<>();
            messages.setValue(new ArrayList<>());
        }
        messagesAdapter.setMessages(messages.getValue());

        // TODO query the database asynchronously, and use messagesAdapter to display the result
        messages.observe(this, ms -> {
            messagesAdapter.setMessages(ms);
            messagesAdapter.notifyDataSetChanged();
        });
        new Thread(new Runnable() {
            @Override
            public void run() {
                messages.postValue(chatDatabase.messageDao().fetchAllMessages());
            }
        }).start();

        // TODO bind the button for "send" to this activity as listener
        sendButton = (Button) findViewById(R.id.send_button);
        sendButton.setOnClickListener(this);

        // TODO initiate binding to the service
        bindService(new Intent(this, ChatService.class), this, Context.BIND_AUTO_CREATE);

        // TODO initialize sendResultReceiver (for receiving notification of message sent)
        sendResultReceiver = new ResultReceiverWrapper(new Handler() {
            @Override
            public void handleMessage(@NonNull android.os.Message msg) {
                Log.e(TAG, "handleMessage: i'm handling");
                Bundle data = msg.getData();
            }
        });
        sendResultReceiver.setReceiver(this);
    }

    public void onResume() {
        super.onResume();
        senderName.setText(Settings.getSenderName(this));
        sendResultReceiver.setReceiver(this);
    }

    public void onPause() {
        super.onPause();
        sendResultReceiver.setReceiver(null);
    }

    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.chatserver_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {

            case R.id.register:
                Intent intent = new Intent(this, RegisterActivity.class);
                startActivity(intent);
                break;

            case R.id.peers:
                Intent peerIntent = new Intent(this, ViewPeersActivity.class);
                startActivity(peerIntent);
                break;

            default:
        }
        return false;
    }


    /*
     * Callback for the SEND button.
     */
    public void onClick(View v) {
        if (!Settings.isRegistered(this)) {

            Toast.makeText(this, R.string.register_necessary, Toast.LENGTH_LONG);
            return;

        }

        if (chatService != null) {
            /*
             * On the emulator, which does not support WIFI stack, we'll send to
             * (an AVD alias for) the host loopback interface, with the server
             * port on the host redirected to the server port on the server AVD.
             */

            String destAddrString = null;

            String destPortString = null;

            String chatRoom = "_default";

            String text = null;

            Date timestamp = DateUtils.now();

            Double latitude = 44.523483;

            Double longitude = -89.574814;

            destAddrString = destinationHost.getText().toString();
            destPortString = destinationPort.getText().toString();

            if (destAddrString.isEmpty()) {
                return;
            }
            InetAddress destAddr = InetAddressUtils.fromString(destAddrString);

            if (destPortString.isEmpty()) {
                return;
            }
            int destPort = Integer.parseInt(destPortString);
            text = messageText.getText().toString();
            if (text.isEmpty()) {
                return;
            }

            chatService.send(destAddr, destPort, chatRoom, text, timestamp, latitude, longitude, sendResultReceiver);

            messageText.setText("");

        }
    }

    @Override
    /**
     * Show a text message when notified that sending a message succeeded or failed
     */
    public void onReceiveResult(int resultCode, Bundle data) {
        switch (resultCode) {
            case RESULT_OK:
                if (resultCode == RESULT_OK) {
                    Toast.makeText(getApplicationContext(), "a success toast message", Toast.LENGTH_LONG).show();
                    new Thread(()->{
                        messages.postValue(chatDatabase.messageDao().fetchAllMessages());
                    }).start();
                }
                break;
            default:
                Toast.makeText(getApplicationContext(), "a failure toast message", Toast.LENGTH_LONG).show();
                break;
        }
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        Log.d(TAG, "Connected to the chat service.");
        chatService = ((ChatService.ChatBinder) service).getService();
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        Log.d(TAG, "Disconnected from the chat service.");
        chatService = null;
    }

    public void notifyMessages() {
        messages.postValue(chatDatabase.messageDao().fetchAllMessages());
    }
}
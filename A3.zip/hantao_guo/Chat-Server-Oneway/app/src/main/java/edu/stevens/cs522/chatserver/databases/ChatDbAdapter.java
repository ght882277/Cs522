package edu.stevens.cs522.chatserver.databases;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import edu.stevens.cs522.chatserver.contracts.MessageContract;
import edu.stevens.cs522.chatserver.contracts.PeerContract;
import edu.stevens.cs522.chatserver.entities.Message;
import edu.stevens.cs522.chatserver.entities.Peer;

/**
 * Created by dduggan.
 */

public class ChatDbAdapter {

    private static final String DATABASE_NAME = "messages.db";

    private static final String MESSAGE_TABLE = "messages";

    private static final String PEER_TABLE = "peers";

    private static final int DATABASE_VERSION = 1;

    private DatabaseHelper dbHelper;

    private SQLiteDatabase db;


    public static class DatabaseHelper extends SQLiteOpenHelper {

        // TODO
        private static final String DROP_PEER_TABLE = "drop table if exists "+PEER_TABLE;

        private static final String DROP_MESSAGE_TABLE = "drop table if exists "+MESSAGE_TABLE;

        private static final String CREATE_PEER_TABLE = "create table peers("
                + "_id integer primary key autoincrement,"
                + "name text,"
                + "timestamp integer,"
                + "latitude real,"
                + "longitude real,"
                + "address text,"
                + "port integer)";

        private static final String CREATE_MESSAGE_TABLE = "create table messages("
                + "_id integer primary key autoincrement,"
                + "chatRoom text,"
                + "message_text text,"
                + "timestamp integer,"
                + "latitude real,"
                + "longitude real,"
                + "sender text,"
                + "sender_id integer)";

        public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            // TODO
            db.execSQL(CREATE_PEER_TABLE);
            db.execSQL(CREATE_MESSAGE_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO
            Log.e("test", "in onUpgrade");

        }
    }


    public ChatDbAdapter(Context _context) {
        dbHelper = new DatabaseHelper(_context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void open() throws SQLException {
        // TODO
        db = dbHelper.getWritableDatabase();
//        db.execSQL("DROP TABLE IF EXISTS " + PEER_TABLE);
//        db.execSQL("DROP TABLE IF EXISTS " + MESSAGE_TABLE);
//        dbHelper.onCreate(db);
    }

    public Cursor fetchAllMessages() {
        // TODO
        return db.query(MESSAGE_TABLE, null, null, null, null, null, null);
    }

    public Cursor fetchAllPeers() {
        // TODO
        return db.query(PEER_TABLE, null, null, null, null, null, null);

    }

    public Peer fetchPeer(long peerId) {
        Cursor cursor = db.rawQuery("select * from " + PEER_TABLE + " where _id = "+String.valueOf(peerId), null);
        cursor.moveToFirst();
        return new Peer(cursor);
    }

    public Cursor fetchMessagesFromPeer(Peer peer) {
        // TODO
        return db.query(MESSAGE_TABLE, new String[]{MessageContract.SENDER_ID}, null, new String[]{String.valueOf(peer.id)}, null, null, null);

    }

    public long persist(Message message) throws SQLException {
        // TODO
        ContentValues out = new ContentValues();
        message.writeToProvider(out);
        return db.replace(MESSAGE_TABLE, null, out);
    }

    /**
     * Add a peer record if it does not already exist; update information if it is already defined.
     */
    public long persist(Peer peer) throws SQLException {
        // TODO
        ContentValues out = new ContentValues();
        peer.writeToProvider(out);
        return db.replace(PEER_TABLE, null, out);
    }

    public void close() {
        // TODO
        db.close();
    }
}
package edu.stevens.cs522.chatserver.activities;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import java.util.ArrayList;

import edu.stevens.cs522.chatserver.R;
import edu.stevens.cs522.chatserver.databases.ChatDbAdapter;
import edu.stevens.cs522.chatserver.entities.Peer;


public class ViewPeersActivity extends Activity implements AdapterView.OnItemClickListener {

    /*
     * TODO See ChatServer for example of what to do, query peers database instead of messages database.
     */

    private ChatDbAdapter chatDbAdapter;

    private SimpleCursorAdapter peerAdapter;

    private ListView peersView;

    private ArrayList<Peer> peers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_peers);

        // TODO initialize peerAdapter with result of DB query
        chatDbAdapter = new ChatDbAdapter(this);
        chatDbAdapter.open();
        Cursor cursor = chatDbAdapter.fetchAllPeers();
        Log.e("viewpeersactivity", "onCreate: "+String.valueOf(cursor.getCount()));
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                R.layout.view_peer, cursor, new String[]{"name"},
                new int[]{R.id.view_user_name}, 0);

        ListView listView = (ListView) findViewById(R.id.peer_list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        /*
         * Clicking on a peer brings up details
         */
        Peer peer = chatDbAdapter.fetchPeer(id);
        Intent intent = new Intent(this, edu.stevens.cs522.chatserver.activities.ViewPeerActivity.class);
        intent.putExtra(edu.stevens.cs522.chatserver.activities.ViewPeerActivity.PEER_KEY, peer);
        startActivity(intent);
    }
}

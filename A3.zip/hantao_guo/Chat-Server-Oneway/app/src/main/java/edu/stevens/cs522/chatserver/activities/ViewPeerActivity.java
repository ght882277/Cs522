package edu.stevens.cs522.chatserver.activities;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import java.text.SimpleDateFormat;

import edu.stevens.cs522.chatserver.R;
import edu.stevens.cs522.chatserver.databases.ChatDbAdapter;
import edu.stevens.cs522.chatserver.entities.Peer;

/**
 * Created by dduggan.
 */

public class ViewPeerActivity extends Activity {

    public static final String PEER_KEY = "peer";

    private ChatDbAdapter chatDbAdapter;

    private TextView viewUserName;

    private TextView viewTimeStamp;

    private TextView viewAddress;

    private TextView viewPort;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_peer);

        Peer peer = getIntent().getParcelableExtra(PEER_KEY);
        if (peer == null) {
            throw new IllegalArgumentException("Expected peer id as intent extra");
        }

        // TODO init the UI
        // TODO init the UI
        viewUserName =  this.findViewById(R.id.view_user_name);
        viewTimeStamp = this.findViewById(R.id.view_timestamp);
        viewAddress = this.findViewById(R.id.view_address);
        viewPort = this.findViewById(R.id.view_port);

        viewUserName.setText(peer.name);
        viewTimeStamp.setText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(peer.timestamp));
        viewAddress.setText(peer.address.getHostName());
        viewPort.setText(String.valueOf(peer.port));
    }

}

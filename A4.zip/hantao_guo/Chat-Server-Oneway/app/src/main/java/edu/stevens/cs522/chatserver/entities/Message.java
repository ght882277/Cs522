package edu.stevens.cs522.chatserver.entities;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import java.util.Date;

import edu.stevens.cs522.chatserver.contracts.MessageContract;

/**
 * Created by dduggan.
 */

public class Message implements Parcelable, Persistable {

    public long id;

    public String chatRoom;

    public String messageText;

    public Date timestamp;

    public Double latitude;

    public Double longitude;

    public String sender;

    public long senderId;

    public Message() {
    }

    public Message(Cursor in) {
        id = MessageContract.getId(in);
        chatRoom = MessageContract.getChatRoom(in);
        messageText = MessageContract.getMessageText(in);
        timestamp = MessageContract.getTimestamp(in);
        latitude = MessageContract.getLatitude(in);
        longitude = MessageContract.getLongitude(in);
        sender = MessageContract.getSender(in);
        senderId = MessageContract.getSenderId(in);
    }

    public Message(Parcel in) {
        id = in.readLong();
        chatRoom = in.readString();
        messageText = in.readString();
        timestamp = new Date(in.readLong());
        latitude = in.readDouble();
        longitude = in.readDouble();
        sender = in.readString();
        senderId = in.readLong();
    }

    @Override
    public void writeToProvider(ContentValues out) {
        out.put("chatRoom", chatRoom);
        out.put(MessageContract.MESSAGE_TEXT, messageText);
        out.put("timestamp", timestamp.getTime());
        out.put("latitude", latitude);
        out.put("longitude", longitude);
        out.put("sender", sender);
        out.put("sender_id", senderId);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(chatRoom);
        dest.writeString(messageText);
        dest.writeLong(timestamp.getTime());
        dest.writeDouble(latitude);
        dest.writeDouble(longitude);
        dest.writeString(sender);
        dest.writeLong(senderId);
    }

    public static final Creator<Message> CREATOR = new Creator<Message>() {

        @Override
        public Message createFromParcel(Parcel source) {
            Message message = new Message();
            message.id = source.readLong();
            message.chatRoom = source.readString();
            message.messageText = source.readString();
            message.timestamp = new Date(source.readLong());
            message.latitude = source.readDouble();
            message.longitude = source.readDouble();
            message.sender = source.readString();
            message.senderId = source.readLong();
            return message;
        }

        @Override
        public Message[] newArray(int size) {
            return new Message[size];
        }

    };

}


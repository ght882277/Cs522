package edu.stevens.cs522.chatserver.activities;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;

import java.text.SimpleDateFormat;

import edu.stevens.cs522.chatserver.R;
import edu.stevens.cs522.chatserver.contracts.PeerContract;
import edu.stevens.cs522.chatserver.entities.Peer;

/**
 * Created by dduggan.
 */

public class ViewPeerActivity extends FragmentActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    public static final String PEER_KEY = "peer";

    private TextView viewUserName;

    private TextView viewTimeStamp;

    private TextView viewAddress;

    private TextView viewPort;

    private SimpleCursorAdapter peerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_peer);

        Peer peer = getIntent().getParcelableExtra(PEER_KEY);
        if (peer == null) {
            throw new IllegalArgumentException("Expected peer as intent extra");
        }

        viewUserName = this.findViewById(R.id.view_user_name);
        viewTimeStamp = this.findViewById(R.id.view_timestamp);
        viewAddress = this.findViewById(R.id.view_address);
        viewPort = this.findViewById(R.id.view_port);

        viewUserName.setText(peer.name);
        viewTimeStamp.setText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(peer.timestamp));
        viewAddress.setText(peer.address.getHostName());
        viewPort.setText(String.valueOf(peer.port));

    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        // Filter messages with the sender id
        return new CursorLoader(this, PeerContract.CONTENT_URI, new String[]{String.valueOf(PeerContract._ID), PeerContract.NAME}, PeerContract._ID + "=" + id,
                null, PeerContract.NAME);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        peerAdapter.swapCursor(data);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        peerAdapter.swapCursor(null);
    }

}

package edu.stevens.cs522.chatserver.providers;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.util.Log;

import androidx.activity.result.contract.ActivityResultContracts;

import java.util.HashMap;
import java.util.Map;

import edu.stevens.cs522.chatserver.contracts.BaseContract;
import edu.stevens.cs522.chatserver.contracts.MessageContract;
import edu.stevens.cs522.chatserver.contracts.PeerContract;
import edu.stevens.cs522.chatserver.entities.Message;
import edu.stevens.cs522.chatserver.entities.Peer;

public class ChatProvider extends ContentProvider {

    public ChatProvider() {
    }

    private static final String AUTHORITY = BaseContract.AUTHORITY;

    private static final String MESSAGE_CONTENT_PATH = MessageContract.CONTENT_PATH;

    private static final String MESSAGE_CONTENT_PATH_ITEM = MessageContract.CONTENT_PATH_ITEM;

    private static final String PEER_CONTENT_PATH = PeerContract.CONTENT_PATH;

    private static final String PEER_CONTENT_PATH_ITEM = PeerContract.CONTENT_PATH_ITEM;


    private static final String DATABASE_NAME = "messages.db";

    private static final String MESSAGE_TABLE = "messages";

    private static final String PEER_TABLE = "peers";

    private static final int DATABASE_VERSION = 1;

    private static final String MESSAGES_TABLE = "messages";

    private static final String PEERS_TABLE = "peers";

    // Create the constants used to differentiate between the different URI requests.
    private static final int MESSAGES_ALL_ROWS = 1;
    private static final int MESSAGES_SINGLE_ROW = 2;
    private static final int PEERS_ALL_ROWS = 3;
    private static final int PEERS_SINGLE_ROW = 4;

    public static class DbHelper extends SQLiteOpenHelper {

        public DbHelper(Context context, String name, CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        private static final String CREATE_PEER_TABLE = "create table peers("
                + "_id integer primary key autoincrement,"
                + "name text,"
                + "timestamp integer,"
                + "latitude real,"
                + "longitude real,"
                + "address text,"
                + "port integer)";

        private static final String CREATE_MESSAGE_TABLE = "create table messages("
                + "_id integer primary key autoincrement,"
                + "chatRoom text,"
                + "message_text text,"
                + "timestamp integer,"
                + "latitude real,"
                + "longitude real,"
                + "sender text,"
                + "sender_id integer)";

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_PEER_TABLE);
            db.execSQL(CREATE_MESSAGE_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            return;
        }

    }

    private static DbHelper dbHelper;

    @Override
    public boolean onCreate() {
        // Initialize your content provider on startup.
        dbHelper = new DbHelper(getContext(), DATABASE_NAME, null, DATABASE_VERSION);
        return true;
    }

    // Used to dispatch operation based on URI
    private static final UriMatcher uriMatcher;

    // uriMatcher.addURI(AUTHORITY, CONTENT_PATH, OPCODE)
    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(AUTHORITY, MESSAGE_CONTENT_PATH, MESSAGES_ALL_ROWS);
        uriMatcher.addURI(AUTHORITY, MESSAGE_CONTENT_PATH_ITEM, MESSAGES_SINGLE_ROW);
        uriMatcher.addURI(AUTHORITY, PEER_CONTENT_PATH, PEERS_ALL_ROWS);
        uriMatcher.addURI(AUTHORITY, PEER_CONTENT_PATH_ITEM, PEERS_SINGLE_ROW);
    }

    protected String contentType(String content) {
        return "vnd.android.cursor/vnd." + BaseContract.AUTHORITY + "." + content + "s";
    }

    protected String contentItemType(String content) {
        return "vnd.android.cursor.item/vnd." + BaseContract.AUTHORITY + "." + content + "s";
    }

    @Override
    public String getType(Uri uri) {
        switch (uriMatcher.match(uri)) {
            case MESSAGES_ALL_ROWS:
                return contentType("message");
            case MESSAGES_SINGLE_ROW:
                return contentItemType("message");
            case PEERS_ALL_ROWS:
                return contentType("peer");
            case PEERS_SINGLE_ROW:
                return contentItemType("peer");
            default:
                throw new IllegalStateException("Unrecognized case.");
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        Log.e("insert", "inserting " );
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long rowId;
        Uri res;
        switch (uriMatcher.match(uri)) {
            case MESSAGES_ALL_ROWS:
                // Make sure to notify any observers
                rowId = db.replace(MESSAGE_TABLE, null, values);
                res = ContentUris.withAppendedId(MessageContract.CONTENT_URI, rowId);
                break;
            case PEERS_ALL_ROWS:
                // Make sure to notify any observers
                rowId = db.replace(PEER_TABLE, null, values);
                res = ContentUris.withAppendedId(MessageContract.CONTENT_URI, rowId);
                break;
            default:
                throw new IllegalStateException("insert: bad case");
        }
        getContext().getContentResolver().notifyChange(res, null);
        return res;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        if (dbHelper == null) {
            Log.e("假的吧", "query: >>>???");
        }
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        SQLiteQueryBuilder sqLiteQueryBuilder = new SQLiteQueryBuilder();
        Cursor c;
        Map<String, String> hashMap = new HashMap<>();
        switch (uriMatcher.match(uri)) {
            case MESSAGES_ALL_ROWS:
                sqLiteQueryBuilder.setTables(MESSAGES_TABLE
                        + " LEFT JOIN " + PEERS_TABLE
                        + " ON (" + MessageContract.SENDER_ID
                        + " = " + PeerContract._ID + ")");
                try {
                    hashMap = new HashMap<>();
                    hashMap.put(MessageContract.SENDER, PeerContract.NAME + " as " + MessageContract.SENDER);
                    for (String field : projection) {
                        if (!hashMap.containsKey(field))
                            hashMap.put(field, field);
                    }
                    sqLiteQueryBuilder.setProjectionMap(hashMap);
                } catch (NullPointerException e) {

                }

                c = db.query(MESSAGES_TABLE, projection, selection, selectionArgs, null, null, sortOrder);
                if (getContext() == null) {
                    Log.e("测试", "空");
                }
                c.setNotificationUri(getContext().getContentResolver(), MessageContract.CONTENT_URI);
                return c;
            case PEERS_ALL_ROWS:
                sqLiteQueryBuilder.setTables(PEERS_TABLE);
                c = db.query(PEERS_TABLE, projection, selection, selectionArgs, null, null, sortOrder);
                c.setNotificationUri(getContext().getContentResolver(), PeerContract.CONTENT_URI);
                return c;

            case MESSAGES_SINGLE_ROW:
                sqLiteQueryBuilder.setTables(MESSAGES_TABLE);
                sqLiteQueryBuilder.appendWhere(MessageContract._ID + " = " + MessageContract.getId(uri));
                break;
            case PEERS_SINGLE_ROW:
                sqLiteQueryBuilder.setTables(PEERS_TABLE);
                sqLiteQueryBuilder.appendWhere(MessageContract._ID + " = " + MessageContract.getId(uri));
                break;
            default:
                throw new IllegalStateException("Query: bad case");
        }
        c = sqLiteQueryBuilder.query(db, projection, selection, selectionArgs, null, null, null);
        c.setNotificationUri(getContext().getContentResolver(), uri);
        return c;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        // Implement this to handle requests to update one or more rows.
        throw new UnsupportedOperationException("Update not implemented");
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // Implement this to handle requests to delete one or more rows.
        throw new UnsupportedOperationException("Delete not implemented");
    }

}

package edu.stevens.cs522.chat.entities;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.Date;

import edu.stevens.cs522.base.DateUtils;
import edu.stevens.cs522.chat.rest.client.Exclude;

/**
 * Created by dduggan.
 */

//@Entity(foreignKeys = @ForeignKey(entity = Peer.class, onDelete = ForeignKey.CASCADE,
//        parentColumns = "id",
//        childColumns = "senderId"),indices = {@Index(value = "senderId")})
@Entity()
public class Message implements Parcelable {

    // Primary key in the database
    @PrimaryKey(autoGenerate = true)
    public long id;

    // Global id provided by the server
    @TypeConverters(DateConverter.class)
    public long seqNum;

    public String chatRoom;

    public String messageText;

    @TypeConverters(DateConverter.class)
    public Date timestamp;

    public Double latitude;

    public Double longitude;

    public String sender;

    public long senderId;

    public Message() {
    }

    public Message(Parcel in) {
        id = in.readLong();
        chatRoom = in.readString();
        messageText = in.readString();
        timestamp = new Date(in.readLong());
        latitude = in.readDouble();
        longitude = in.readDouble();
        sender = in.readString();
        senderId = in.readLong();
    }

    @Override
    public String toString() {
        return messageText;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(chatRoom);
        dest.writeString(messageText);
        dest.writeLong(timestamp.getTime());
        dest.writeDouble(latitude);
        dest.writeDouble(longitude);
        dest.writeString(sender);
        dest.writeLong(senderId);
    }

    public static final Creator<Message> CREATOR = new Creator<Message>() {

        @Override
        public Message createFromParcel(Parcel source) {
            Message message = new Message();
            message.id = source.readLong();
            message.chatRoom = source.readString();
            message.messageText = source.readString();
            message.timestamp = new Date(source.readLong());
            message.latitude = source.readDouble();
            message.longitude = source.readDouble();
            message.sender = source.readString();
            message.senderId = source.readLong();
            return message;
        }

        @Override
        public Message[] newArray(int size) {
            return new Message[size];
        }

    };

}
package edu.stevens.cs522.chat.databases;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import edu.stevens.cs522.chat.entities.Message;
import edu.stevens.cs522.chat.entities.Peer;

@Dao
/**
 * These are synchronous operations used on a background thread for syncing messages with a server.
 */
public abstract class RequestDAO {

    /**
     * Get the last sequence number in the messages database.
     */
    @Query("SELECT MAX(seqNum) AS max_seq_num FROM Message WHERE seqNum <> 0")
    public abstract long getLastSequenceNumber();

    /**
     * Get all unsent messages, identified by sequence number = 0.
     */
    @Query("SELECT * FROM Message WHERE seqNum = 0")
    public abstract List<Message> getUnsentMessages();

    @Insert
    protected abstract void insert(Message message);

    @Update
    protected abstract void update(Message message);

    /**
     * Insert other peer's messages and update our own, with input from server.
     */
    public void upsert(long senderId, Message message) {
        if (senderId == message.senderId) {
            // One of our own messages returned from the server, update sequenceId
            update(message);
        } else {
            // Another peer's message, with sequenceId set by server
            message.id = 0;
            insert(message);
        }
    }

}

package edu.stevens.cs522.chat.sync;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import edu.stevens.cs522.chat.rest.RequestProcessor;
import edu.stevens.cs522.chat.rest.request.ChatServiceRequest;
import edu.stevens.cs522.chat.rest.request.ChatServiceResponse;
import edu.stevens.cs522.chat.rest.request.ErrorResponse;
import edu.stevens.cs522.chat.rest.request.SynchronizeRequest;

public class SyncWorker extends Worker {

    private static final String TAG = SyncWorker.class.getCanonicalName();

    private RequestProcessor processor;

    public SyncWorker(
            @NonNull Context context,
            @NonNull WorkerParameters params) {
        super(context, params);
        processor = new RequestProcessor(context);
    }


    @Override
    public Result doWork() {

        Log.e(TAG, "WorkManager: Performing sync request.");

        ChatServiceRequest request = new SynchronizeRequest();

        ChatServiceResponse response = processor.process(request);

        if (response instanceof ErrorResponse) {
            Log.i(TAG, "Failed to sync chat messages, will retry: "+response.httpResponseMessage);
            return Result.retry();
        }

        return Result.success();
    }
}

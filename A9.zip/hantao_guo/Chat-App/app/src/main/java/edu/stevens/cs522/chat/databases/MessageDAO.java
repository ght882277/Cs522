package edu.stevens.cs522.chat.databases;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import java.util.List;

import edu.stevens.cs522.chat.entities.Message;
import edu.stevens.cs522.chat.entities.Peer;

@Dao
public abstract class MessageDAO {

    @Query("SELECT * FROM Message")

    public abstract List<Message> fetchAllMessages();

    @Query("SELECT * FROM Message WHERE senderId = :peerId")
    public abstract List<Message> fetchMessagesFromPeer(long peerId);

    @Transaction
    @Insert
    public abstract void insert(Message message);

    @Transaction
    @Update
    protected abstract void update(Message message);

    @Transaction
    public void upsert(long senderId, Message message) {
        if (senderId == message.senderId) {
            // One of our own messages returned from the server, update sequenceId
            update(message);
        } else {
            // Another peer's message, with sequenceId set by server
            message.id = 0;
            insert(message);
        }
    }

}

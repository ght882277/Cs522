package edu.stevens.cs522.chat.databases;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.List;

import edu.stevens.cs522.chat.entities.Peer;

@Dao
public abstract class PeerDAO {

    @Query("SELECT * FROM Peer")
    public abstract List<Peer> fetchAllPeers();

    //public abstract ListenableFuture<Peer> fetchPeer(long peerId);

    @Query("SELECT id FROM Peer where name = :name")
    protected abstract long getPeerId(String name);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    protected abstract long insert(Peer peer);

    @Update
    protected abstract void update(Peer peer);

    @Transaction
    /**
     * This operation must be transactional, to avoid race condition
     * between conflict on insert and update.
     */
    public long upsert(Peer peer) {
        long id = getPeerId(peer.name);
        if (id == 0) {
            id = insert(peer);
        } else {
            peer.id = id;
            update(peer);
        }
        return id;
    }
}

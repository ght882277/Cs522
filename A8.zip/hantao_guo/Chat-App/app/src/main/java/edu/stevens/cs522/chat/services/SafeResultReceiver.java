package edu.stevens.cs522.chat.services;

import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.v4.os.IResultReceiver;
import android.util.Log;

import androidx.annotation.NonNull;

/**
 * Created by dduggan.
 */

public class SafeResultReceiver implements Parcelable {

    private static final String TAG = SafeResultReceiver.class.getCanonicalName();

    // Callback that is invoked with the result.
    private IReceive target;

    // Handler thread on which to execute the callback (should be main loop).
    private final Handler handler;

    // This is the callback object that we will send as a client stub to the service.
    private final IResultReceiver receiver;

    public SafeResultReceiver(@NonNull Handler handler) {
        this.handler = handler;  // Could be new Handler(Looper.mainLooper())
        this.receiver = new IResultReceiver.Stub() {
            // We will send a stub of this callback object to the other process
            @Override
            public void send(int resultCode, Bundle data) throws RemoteException {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (target != null) {
                            target.onReceiveResult(resultCode, data);
                        }
                    }
                });
            }
        };
    }

    /**
     * This will be executed on the service side to return a result via the receiver.
     * The receiver is either the local receiver callback, or a stub if in another process.
     * @param resultCode
     * @param data
     */
    public void send(int resultCode, Bundle data) {
        try {
            receiver.send(resultCode, data);
        } catch (RemoteException e) {
            Log.e(TAG, "IPC failure while returning result to result receiver!", e);
        }
    }

    /**
     * The callback that the receiver invokes.
     */
    public interface IReceive {
        public void onReceiveResult(int resultCode, Bundle data);
    }

    public void setTarget(IReceive target) {
        this.target = target;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel out, int flags) {
        // We marshall this as a client stub that will be invoked via IPC.
        out.writeStrongBinder(receiver.asBinder());
    }

    public SafeResultReceiver(Parcel in) {
        this.handler = null;
        this.target = null;
        // We only unmarshall the client stub.
        this.receiver = IResultReceiver.Stub.asInterface(in.readStrongBinder());
    }

    public static final Parcelable.Creator<SafeResultReceiver> CREATOR = new Parcelable.Creator<SafeResultReceiver>() {
        public SafeResultReceiver createFromParcel(Parcel in) {
            return new SafeResultReceiver(in);
        }

        public SafeResultReceiver[] newArray(int size) {
            return new SafeResultReceiver[size];
        }
    };

}

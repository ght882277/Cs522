package edu.stevens.cs522.chat.rest;

import android.content.Context;
import android.util.Log;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.List;

import edu.stevens.cs522.base.DateUtils;
import edu.stevens.cs522.chat.databases.ChatDatabase;
import edu.stevens.cs522.chat.databases.MessageDAO;
import edu.stevens.cs522.chat.entities.Message;
import edu.stevens.cs522.chat.entities.Peer;
import edu.stevens.cs522.chat.location.CurrentLocation;
import edu.stevens.cs522.chat.rest.request.ErrorResponse;
import edu.stevens.cs522.chat.rest.request.PostMessageRequest;
import edu.stevens.cs522.chat.rest.request.PostMessageResponse;
import edu.stevens.cs522.chat.rest.request.RegisterRequest;
import edu.stevens.cs522.chat.rest.request.RegisterResponse;
import edu.stevens.cs522.chat.rest.request.ChatServiceRequest;
import edu.stevens.cs522.chat.rest.request.ChatServiceResponse;
import edu.stevens.cs522.chat.rest.request.SynchronizeRequest;
import edu.stevens.cs522.chat.settings.Settings;
import edu.stevens.cs522.base.StringUtils;

/**
 * Created by dduggan.
 */

public class RequestProcessor {

    private static final String TAG = RequestProcessor.class.getCanonicalName();

    private final Context context;

    private final CurrentLocation location;

    private final RestMethod restMethod;

    private final ChatDatabase chatDatabase;

    public RequestProcessor(Context context) {
        this.context = context;

        this.location = new CurrentLocation(context);

        this.restMethod = new RestMethod(context);

        this.chatDatabase = ChatDatabase.getInstance(context);
    }

    /**
     * We use the Visitor pattern to dispatch to the appropriate request processing.
     * This is also where we attach metadata to the request that is attached as
     * application-specific request headers to the HTTP request.  We have to do this because
     * synchronization requests are launched by the alarm manager using a pending intent,
     * and we cannot attach extra information to a PI.
     * @param request
     * @return
     */
    public ChatServiceResponse process(ChatServiceRequest request) {
        request.appID = Settings.getAppId(context);
        request.timestamp = DateUtils.now();
        request.latitude = location.getLatitude();
        request.longitude = location.getLongitude();
        return request.process(this);
    }

    public ChatServiceResponse perform(RegisterRequest request) {

        Log.d(TAG, "Registering as " + request.chatname);
        ChatServiceResponse response = restMethod.perform(request);

        if (response instanceof RegisterResponse) {
            /*
             * Add a record for this peer to the local database.  The PK is the sender ID
             * returned from registration on the server.
             */
            RegisterResponse registration = (RegisterResponse) response;

            final Peer peer = new Peer();
            peer.id = registration.getSenderId();
            peer.name = request.chatname;
            peer.timestamp = request.timestamp;
            peer.latitude = request.latitude;
            peer.longitude = request.longitude;
            chatDatabase.peerDao().upsert(peer);
            Log.e(TAG, "perform: register id="+registration.getSenderId());
            Settings.saveServerUri(context,request.chatServer);
            Settings.saveChatName(context,request.chatname);
            Settings.saveSenderId(context,registration.getSenderId());
        }
        return response;
    }

    public ChatServiceResponse perform(PostMessageRequest request) {
        long id = -1;  // Local PK of the message in the DB

        chatDatabase.messageDao().upsert(id,request.message);

       if (!Settings.SYNC) {
            /*
             * We are synchronously uploading messages to the server.
             */
            ChatServiceResponse response = restMethod.perform(request);
            if (response instanceof PostMessageResponse) {
                Log.e(TAG, "perform: sender="+request.message.sender+" senderid="+request.message.senderId);
                PostMessageResponse postMessageResponse = (PostMessageResponse)response;

                //  update the message in the database with the sequence number
                chatDatabase.messageDao().upsert(((PostMessageResponse) response).getMessageId(),request.message);
            }
            return response;
        } else {
            /*
             * We will just insert the message into the database, and rely on background
             * synchronization driven by alarms to upload it asynchronously.
             */
            return request.getDummyResponse();
        }
    }

    private final Type peerType = TypeToken.get(Peer.class).getType();

    private final Type messageType = TypeToken.get(Message.class).getType();

    /**
     * For SYNC: perform a sync using a request manager.  These requests are
     * generated from an alarm that is scheduled at periodic intervals.
     */
    public ChatServiceResponse perform(SynchronizeRequest request) {

        throw new IllegalStateException("Unimplemented synchonization!");

    }


}

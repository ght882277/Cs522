package edu.stevens.cs522.chat.activities;

import android.os.Bundle;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.List;

import edu.stevens.cs522.chat.R;
import edu.stevens.cs522.chat.databases.ChatDatabase;
import edu.stevens.cs522.chat.entities.Message;
import edu.stevens.cs522.chat.entities.Peer;
import edu.stevens.cs522.chat.ui.TextAdapter;

/**
 * Created by dduggan.
 */

public class ViewPeerActivity extends FragmentActivity {

    public static final String PEER_KEY = "peer";

    private ChatDatabase chatDatabase;

    private LiveData<List<Message>> messages;

    private TextAdapter<Message> messageAdapter;

    private RecyclerView messagesList;

    private Peer peer;

    private TextView viewUserName;

    private TextView viewTimeStamp;

    private TextView viewAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_peer);

        peer = getIntent().getParcelableExtra(PEER_KEY);
        if (peer == null) {
            throw new IllegalArgumentException("Expected peer id as intent extra");
        }

        // init the UI
        viewUserName = this.findViewById(R.id.view_user_name);
        viewTimeStamp = this.findViewById(R.id.view_timestamp);
        viewAddress = this.findViewById(R.id.view_address);

        viewUserName.setText(peer.name);
        viewTimeStamp.setText(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(peer.timestamp));
        viewAddress.setText(String.valueOf(peer.latitude)+";"+ String.valueOf(peer.longitude));
    }

}

package edu.stevens.cs522.chat.rest;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.ResultReceiver;
import android.util.Log;

import edu.stevens.cs522.base.DateUtils;
import edu.stevens.cs522.chat.entities.Message;
import edu.stevens.cs522.chat.location.CurrentLocation;
import edu.stevens.cs522.chat.rest.request.PostMessageRequest;
import edu.stevens.cs522.chat.rest.request.RegisterRequest;
import edu.stevens.cs522.chat.rest.request.ChatServiceRequest;
import edu.stevens.cs522.chat.services.RequestService;
import edu.stevens.cs522.chat.services.ResultReceiverWrapper;
import edu.stevens.cs522.chat.services.SafeResultReceiver;
import edu.stevens.cs522.chat.settings.Settings;


/**
 * Created by dduggan.
 */

public class ChatHelper {

    private final Context context;

    private final CurrentLocation location;

    public ChatHelper(Context context) {
        this.context = context;
        this.location = new CurrentLocation(context);
    }

    public void register (Uri chatServer, String chatName, ResultReceiverWrapper resultReceiver) {
        if (chatName != null && !chatName.isEmpty()) {
            // Registration will be done on a background thread by RequestService.
            RegisterRequest request = new RegisterRequest(chatServer,chatName);
            Settings.saveChatName(context, chatName);
            addRequest(request,resultReceiver);
        }
    }

    public void postMessage(String chatRoom, String messageText, ResultReceiverWrapper receiver) {
        if (messageText != null && !messageText.isEmpty()) {
            Message mesg = new Message();
            mesg.messageText = messageText;
            mesg.chatRoom = chatRoom;
            mesg.timestamp = DateUtils.now();
            mesg.latitude = location.getLatitude();
            mesg.longitude = location.getLongitude();
            mesg.sender = Settings.getChatName(context);
            mesg.senderId = Settings.getSenderId(context);

            // Depending on Settings.SYNC, message will be sent immediately on background
            // thread, or just added locally and eventually synchronized with server database.
            PostMessageRequest request = new PostMessageRequest(mesg);
            addRequest(request,receiver);
        }
    }

    /**
     * Send request to service that processes the request on a background thread.
     */
    private void addRequest(ChatServiceRequest request, ResultReceiverWrapper receiver) {
        RequestService.enqueueWork(context, createIntent(context, request, receiver));
    }

    private void addRequest(ChatServiceRequest request) {
        addRequest(request, null);
    }

    /**
     * Use an intent to send the request to a background service. The request is included as a Parcelable extra in
     * the intent. The key for the intent extra is in the RequestService class.
     */
    private static Intent createIntent(Context context, ChatServiceRequest request, ResultReceiverWrapper receiver) {
        Intent intent = new Intent(context, RequestService.class);
        intent.putExtra(RequestService.SERVICE_REQUEST_KEY, request);
        if (receiver != null) {
            intent.putExtra(RequestService.RESULT_RECEIVER_KEY, receiver);
        }
        return intent;
    }

    private static Intent createIntent(Context context, ChatServiceRequest request) {
        return createIntent(context, request, null);
    }

}

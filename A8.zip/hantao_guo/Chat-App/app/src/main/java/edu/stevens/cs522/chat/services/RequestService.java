package edu.stevens.cs522.chat.services;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.ResultReceiver;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.JobIntentService;

import edu.stevens.cs522.chat.rest.RequestProcessor;
import edu.stevens.cs522.chat.rest.request.ErrorResponse;
import edu.stevens.cs522.chat.rest.request.ChatServiceRequest;
import edu.stevens.cs522.chat.rest.request.ChatServiceResponse;
import edu.stevens.cs522.chat.rest.request.SynchronizeRequest;

/**
 * A service for handling asynchronous task requests on a separate handler thread.
 */
public class RequestService extends JobIntentService {

    private static final String TAG = RequestService.class.getCanonicalName();

    public static final String SERVICE_REQUEST_KEY = "edu.stevens.cs522.chat.rest.extra.REQUEST";

    public static final String RESULT_RECEIVER_KEY = "edu.stevens.cs522.chat.rest.extra.RECEIVER";

    private RequestProcessor processor;

    /**
     * Unique job ID for this service.
     */
    static final int JOB_ID = 1000;

    /**
     * Convenience method for enqueuing work in to this service.
     */
    public static void enqueueWork(Context context, Intent work) {
        enqueueWork(context, RequestService.class, JOB_ID, work);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        processor = new RequestProcessor(this);
    }

    @Override
    protected void onHandleWork(@NonNull Intent intent) {
        /*
         * This will be run on a background thread, with wake lock already obtained.
         */
        ChatServiceRequest request = intent.getParcelableExtra(SERVICE_REQUEST_KEY);
        if (request == null) {
            // The intent was generated from a periodic alarm.
            request = new SynchronizeRequest();
        }
        ResultReceiver receiver = intent.getParcelableExtra(RESULT_RECEIVER_KEY);

        ChatServiceResponse response = processor.process(request);

        if (receiver != null) {
            // Use receiver to call back to activity

            if (response instanceof ErrorResponse) {
                // let activity know request failed
                receiver.send(Activity.RESULT_CANCELED, null);
            } else {
                // let activity know request succeeded
                receiver.send(Activity.RESULT_OK, null);
            }
        } else {
            Log.d(TAG, "Missing receiver");
        }
    }

}
